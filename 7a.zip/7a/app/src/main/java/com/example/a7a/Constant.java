package com.example.a7a;

/**
 * Created by User on 2/23/2018.
 */

public class Constant {
    public static boolean isToggle = true;
    public static String color = "Dark";
    public static int theme = android.R.style.Theme_Light;
}
