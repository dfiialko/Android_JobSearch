package com.example.miterm_preparation_array;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ResultActivity extends AppCompatActivity {
private Button btnOK;

private EditText txtResultName,txtResultDays;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        txtResultDays = findViewById(R.id.txtResultDays);
        txtResultName = findViewById(R.id.txtResultName);

        String name = getIntent().getStringExtra("name");
        int days = getIntent().getIntExtra("days",0);
        txtResultName.setText(name);
        if(days != 0){
            txtResultDays.setText(Integer.valueOf(days).toString());
        }
        btnOK = findViewById(R.id.btnOK);
        //editText = findViewById(R.id.editText);

        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               onReturn();
            }
        });
    }

    @Override
    public void onBackPressed() {
        onReturn();
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor;
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        editor = sharedPreferences.edit();

        editor.putString("sharedPrefName",txtResultName.getText().toString());
        // Calling parse int on empty string crashes
        if(txtResultDays.length() > 0){
            editor.putInt("sharedPRefDays",Integer.parseInt(txtResultDays.getText().toString()));
        }
        editor.commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String name = sharedPreferences.getString("sharedPrefName","NONAME");
        int days = sharedPreferences.getInt("sharedPRefDays",0);

        Log.d("name",name);
        Log.d("days",Integer.valueOf(days).toString());
    }

    public void onReturn(){
        Intent intent = new Intent();
        if(txtResultDays.length() > 0 && txtResultName.length() > 0){
            setResult(Activity.RESULT_OK,intent);

        }else{
            setResult(Activity.RESULT_CANCELED,intent);
        }
        finish();
    }
}
