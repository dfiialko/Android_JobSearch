package com.example.miterm_preparation_array;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private Button btnGenerateArray, btnStart;
    private EditText txtCelcius, txtFarenheit, txtName, txtDays;
    private RadioGroup rgCalc;
    private TextView txtResult;
    private int[] array;
    private static int REQUEST_CODE = 1;


    // Overrides on result listener
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // check if Result_OK and Request Code is the one that we passed
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            // Get data from preferences
            String name = sharedPreferences.getString("sharedPrefName", "NONAME");
            int days = sharedPreferences.getInt("sharedPRefDays", 0);

            // Set text on result
            txtDays.setText(Integer.valueOf(days).toString());
            txtName.setText(name);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadArray();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnGenerateArray = findViewById(R.id.btnGenerateArray);
        rgCalc = findViewById(R.id.rgCalc);
        txtResult = findViewById(R.id.txtResult);


        txtCelcius = findViewById(R.id.txtCelcius);
        txtFarenheit = findViewById(R.id.txtFarenheit);

        txtCelcius.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (txtCelcius.hasFocus()) {
                    if (charSequence.length() > 0) {
                        double farenheit = Double.valueOf(charSequence.toString()) * 9 / 5 + 32;
                        //Math.round((Double.valueOf(charSequence.toString()) * 1.2)*100) / 100.00;
                        txtFarenheit.setText(Double.toString(farenheit));
                    } else {
                        txtFarenheit.setText("");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        txtFarenheit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (txtFarenheit.hasFocus()) {
                    if (charSequence.length() > 0) {
                        double celcius = (Double.valueOf(charSequence.toString()) - 32) * 5 / 9;
                        //Math.round((Double.valueOf(charSequence.toString()) * 1.2)*100) / 100.00;
                        txtCelcius.setText(Double.toString(Math.round(celcius) * 100 / 100.00));
                    } else {
                        txtCelcius.setText("");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
        btnGenerateArray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loadArray();
                txtResult.setText("");
            }
        });

        rgCalc.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkRB) {
                switch (checkRB) {
                    case R.id.rbMean:
                        txtResult.setText(Double.toString(statRes(R.id.rbMean)));
                        break;
                    case R.id.rbMedian:
                        txtResult.setText(Double.toString(statRes(R.id.rbMedian)));
                        break;
                    case R.id.rbRange:
                        txtResult.setText(Double.toString(statRes(R.id.rbRange)));
                        break;
                }
            }
        });


        btnStart = findViewById(R.id.btnStart);
        txtName = findViewById(R.id.txtName);
        txtDays = findViewById(R.id.txtDays);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                if (txtName.length() > 0 && txtDays.length() > 0) {
                    intent.putExtra("name", txtName.getText().toString());
                    intent.putExtra("days", Integer.valueOf(txtDays.getText().toString()));
                }
                    startActivityForResult(intent, REQUEST_CODE);
            }
        });

    }

    public double statRes(int method) {
        double result = 0;
        Arrays.sort(array);
        if (method == R.id.rbMean) {
            double sum = 0;
            for (int i = 0; i < array.length; i++) {
                sum += array[i];
            }
            result = sum / array.length;
        }
        if (method == R.id.rbMedian) {
            if (array.length % 2 == 0)
                result = ((double) array[array.length / 2] + (double) array[array.length / 2 - 1]) / 2;
            else
                result = (double) array[array.length / 2];
        }
        if (method == R.id.rbRange) {
            // Array sorted already so it return largest - smallest number
            result = array[array.length - 1] - array[0];
        }

        return result;
    }

    public void loadArray() {
        Log.d("loadArray", "loadArray Called. 1000 random numbers generated");
        int[] arrayGenerated = new int[1000];
        for (int i = 0; i < 1000; i++) {
            arrayGenerated[i] = (int) (Math.random() * 999 + 1);
        }
        array = arrayGenerated;
    }
}


