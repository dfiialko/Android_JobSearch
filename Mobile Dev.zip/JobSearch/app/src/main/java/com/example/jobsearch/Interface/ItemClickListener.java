package com.example.jobsearch.Interface;

import android.view.View;

/**
 * Created by User on 3/26/2018.
 */

public interface ItemClickListener {
    void onClick(View view,int position,boolean isLongClick);
}
